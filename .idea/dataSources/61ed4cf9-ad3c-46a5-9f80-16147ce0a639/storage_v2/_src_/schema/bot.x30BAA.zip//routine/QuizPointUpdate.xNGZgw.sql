create
    definer = root@localhost procedure QuizPointUpdate(IN pUserName varchar(40), IN pUserId varchar(25), OUT pUserPoint int)
BEGIN
	IF NOT EXISTS (SELECT 0 FROM bot.QuizUser WHERE userName = pUserName)
	THEN
		INSERT INTO bot.quizuser (userId, userName, quizPoint) VALUES (pUserId,pUserName,5);
		SET pUserPoint = 1;
	ELSE
		UPDATE bot.quizuser
		SET quizPoint = quizPoint + 5
		WHERE userId = pUserId;
        SET pUserPoint = 2;
	END IF;
END;

